<template>
  <span>
    <img src="@/assets/logo.png" style="margin-top: 0px;width:130px;" />
    <img src="@/assets/gamelogo.png" style="margin-left: 20px;margin-top: 0px;width:100px;" />
  </span>
</template>

<script>
export default {
  name: "Title",
};
</script>